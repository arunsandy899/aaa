apt update
pkg install git
pkg install python 
pkg install figlet
rm trial* hi*
wget -q "https://raw.githubusercontent.com/EthicalHacker121/honey1day/main/hi.py"
clear
python hi.py
